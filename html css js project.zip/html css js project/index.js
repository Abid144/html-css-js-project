const toggle = document.querySelector('.toggler');
const ul = document.querySelector('ul');
console.log(ul);
function handleClick() {
  if(ul.style.display === "block"){
   ul.style.display = "none";
  } else {
   ul.style.display = "block";
  }
}

toggle.addEventListener('click',handleClick)


// clock
const time = document.querySelector('.time');
const date = document.querySelector('.date');
const day = document.querySelector('.day');

setInterval(() => {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months= ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const outPuts ={
    hours: showZero( new Date().getHours()),
    minutes: showZero( new Date().getMinutes()),
    seconds: showZero( new Date().getSeconds()),
    date: showZero( new Date().getDate()),
    month : showZero( months[new Date().getMonth()] ),
    year: new Date().getFullYear(),
    day: showZero( days[new Date().getDay()] ),
  };

  showTime = `${outPuts.hours}: ${outPuts.minutes}: ${outPuts.seconds} <span>${amPm(outPuts.hours)}</span>`;
  showDate= `${outPuts.date}, ${outPuts.month}, ${outPuts.year}`;
  time.innerHTML = showTime;
  date.innerHTML = showDate;
  day.innerHTML = outPuts.day;
},1000);

function showZero(n = 0) {
  if(n < 10){
    return `0${n}`;
  }else return n
}
function amPm(a){
  if(a > 11){
      return "PM"
  } else return "AM"
}

// loading

const loading = document.querySelector('.loading');
const body = document.querySelector('body');
console.log(loading);
window.addEventListener('load',outline);

function outline() {
  loading.classList.add('hide');
}